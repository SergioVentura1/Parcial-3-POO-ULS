<?php
session_start();

    $conn = mysqli_connect('localhost','root','','crud_tareas');
    /*if(isset($conn)){
        echo "Conexion exitosa";
    }else{
        echo "ERROr";
    }*/

?>